from kari.det.utils import LOGGER

def check_kari_det():
    LOGGER.info('check_det')