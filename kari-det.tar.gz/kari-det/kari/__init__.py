# KARI-Detection, GPL-3.0 license

__version__ = '0.9'

#from kari.det.engine.model import YOLO
#from kari.det.utils.checks import check_yolo as checks

__all__ = '__version__' #, 'YOLO', 'checks'  # allow simpler import